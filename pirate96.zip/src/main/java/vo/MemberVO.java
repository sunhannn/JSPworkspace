package vo;

public class MemberVO {
	private String M_ID;
	private String M_PW;
	private String M_NAME;
	private String M_PH;
	private String M_ADDR;
	private String M_EMAIL;
	private String M_GENDER;

	public String getM_ID() {
		return M_ID;
	}

	public void setM_ID(String m_ID) {
		M_ID = m_ID;
	}

	public String getM_PW() {
		return M_PW;
	}

	public void setM_PW(String m_PW) {
		M_PW = m_PW;
	}

	public String getM_NAME() {
		return M_NAME;
	}

	public void setM_NAME(String m_NAME) {
		M_NAME = m_NAME;
	}

	public String getM_PH() {
		return M_PH;
	}

	public void setM_PH(String m_PH) {
		M_PH = m_PH;
	}

	public String getM_ADDR() {
		return M_ADDR;
	}

	public void setM_ADDR(String m_ADDR) {
		M_ADDR = m_ADDR;
	}

	public String getM_EMAIL() {
		return M_EMAIL;
	}

	public void setM_EMAIL(String m_EMAIL) {
		M_EMAIL = m_EMAIL;
	}

	public String getM_GENDER() {
		return M_GENDER;
	}

	public void setM_GENDER(String m_GENDER) {
		M_GENDER = m_GENDER;
	}

}
